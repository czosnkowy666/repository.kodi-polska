# -*- coding: utf-8 -*-
import sys
from lib import tvpvod

tvpvod.route(sys.argv)
